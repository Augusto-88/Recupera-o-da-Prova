-- Active: 1781128334869@@127.0.0.1@3307@techfactory_db
use DATABASE techfactory_db;
DROP TABLE departamentos;
CREATE TABLE departamentos(
id_departamento int auto_increment PRIMARY KEY,
nome_departamento VARCHAR(20) not null unique,
local_departamento VARCHAR(20) not null,
id_colaborador int,
Foreign Key (id_colaborador) REFERENCES colaborador(id_colaborador)
);

DROP TABLE colaborador;
CREATE TABLE colaborador(
id_colaborador int AUTO_INCREMENT PRIMARY KEY,
nome_colaborador varchar(20) not null,
cpf char(11) not null unique,
email_corporativo VARCHAR(40) not null unique,
cargo VARCHAR(20) not null,
data_adimissao DATE not null
);
DROP TABLE equipamentos;
CREATE TABLE equipamentos(
id_equipamento int AUTO_INCREMENT PRIMARY KEY,
nome_equipamento VARCHAR(20) not null,
patrimonio varchar(50) not null,
descricao varchar(20),
fabricante VARCHAR(20) not null,
modelo varchar(20) not null,
data_aquisicao date not null,
status varchar(20) not null
);

create table categoria(
id_categoria AUTO_INCREMENT
);
DROP TABLE fornecedor;

CREATE TABLE fornecedor(

);
