CREATE TABLE departamentos(
id_dep
);