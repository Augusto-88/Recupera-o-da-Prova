-- Active: 1781128334869@@127.0.0.1@3307@techfactory_db
use DATABASE techfactory_db;

CREATE TABLE departamentos(
id_departamento int auto_increment PRIMARY KEY,
nome_departamento VARCHAR(20) not null unique,
local_departamento VARCHAR(20) not null
);


CREATE TABLE colaborador(
id_colo
);