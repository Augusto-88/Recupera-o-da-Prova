CREATE TABLE departamentos(

);