CREATE TABLE departamentos(
id_departamento
);